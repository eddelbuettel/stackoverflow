#include <Rcpp.h>
#include <lapacke.h>

// [[Rcpp::export]]
int test_LAPACK(){
	  return(1);
}
