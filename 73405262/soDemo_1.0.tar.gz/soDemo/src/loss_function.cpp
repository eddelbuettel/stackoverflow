// [[Rcpp::depends(RcppArmadillo)]]
//
#include <RcppArmadillo.h>

using namespace Rcpp;

//' Check function.
//'
//' @param x vector
//' @param tau percentile
//' @return y new vector
//' @export
// [[Rcpp::export(rho_koenker)]]
arma::vec rho_koenker(arma::vec x, double tau){
int n = x.n_elem;
arma::vec y(n);
for(int i = 0; i < n; ++i){
    if(x(i)<0){
      y(i) = x(i)*(tau-1);
    } else {
      y(i) = x(i)*tau;
    }
 }
return(y);
}

//' Quantile regression loss function
//'
//' @param beta parameter
//' @param x matrix
//' @param y vector
//' @param tau percentile
//' @param N total number of observations
//' @param d beta's length
//' @return eta numeric
//' @export
// [[Rcpp::export(loss_qr)]]
double loss_qr(arma::vec beta, arma::mat x, arma::vec y, double tau, int N, int d){
   double eta = 0;
   arma::vec res(N);
   arma::vec rho(N);
   res = y - (x * beta);
   rho = rho_koenker(res,tau);
   eta = accu(rho);
return(eta);
}
